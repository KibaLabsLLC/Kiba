# Kiba Insights

A quiet daily briefing for your Stripe Dashboard home page. No charts, no
tables — just a few plain sentences about what happened yesterday.

## Set up

This folder is now a complete project by itself — every file
`stripe generate app` would normally produce is already here
(`package.json`, `tsconfig.json`, `jest.config.ts`, `.gitignore`, etc.),
built and verified by hand. You do **not** need to run
`stripe generate app` at all, which matters if that plugin crashes on
your machine (see the AVX2 note below).

1. Get the project onto the machine you'll run the CLI from, then:
   ```bash
   npm install
   npm run test   # optional — confirms everything's still green
   ```

2. Install just the `apps` CLI plugin (not `generate` — we don't need it):
   ```bash
   stripe plugin install apps
   stripe login
   ```

3. Grant the three permissions (the CLI will prompt for these on first
   `stripe apps start` if you skip this step):

   ```bash
   stripe apps grant permission "customer_read" "Count how many people paid you recently."
   stripe apps grant permission "charge_read" "Read yesterday's payments to summarize them in plain language."
   stripe apps grant permission "balance_read" "Show your current available balance."
   ```

4. Preview it:

   ```bash
   stripe apps start
   ```

   It renders on the Dashboard **Home** page.

## Verified so far

This project's been type-checked (`npx tsc`) and test-run (`npx jest`)
against the real `@stripe/ui-extension-sdk` v9.3.0 — both pass. One real
bug that surfaced along the way: despite Stripe's docs saying "only
React 17," this SDK version pins **React 18.3.1** internally
(`node_modules/@stripe/ui-extension-sdk/package.json`). Installing
React 17 alongside it causes two copies of React to load at once,
which breaks all hooks with "Invalid hook call." `package.json` here
is already pinned to React 18.3.1 to match — don't downgrade it.

What's *not* yet verified: the actual `stripe apps start` bundle and
Dashboard render, since that needs the CLI itself (blocked separately
by the `generate` plugin's AVX2 crash on your CPU — the `apps` plugin
loaded fine though, so `stripe apps start` may just work once you're
past scaffolding).

## Notes

- All the "personality" is in the sentences (`lines()` in
  `KibaInsights.tsx`) — tweak the wording there; it's the easiest thing
  to make sound more like you.
- Styling uses Stripe's design tokens (`primary`/`secondary` text,
  `neutral` keyline) rather than custom colors, which keeps it
  black-and-white by default and consistent with the rest of the
  Dashboard.
- "Yesterday" is a rolling 24 hours from now, not calendar-day — simpler
  to reason about and still reads naturally in the morning.
