import React from 'react';
import {render} from '@stripe/ui-extension-sdk/testing';
import {getMockContextProps} from '@stripe/ui-extension-sdk/testing';
import KibaInsights from './KibaInsights';

test('renders without crashing', () => {
  const context = getMockContextProps();
  const {wrapper} = render(<KibaInsights {...context} />);
  expect(wrapper).toBeTruthy();
});
