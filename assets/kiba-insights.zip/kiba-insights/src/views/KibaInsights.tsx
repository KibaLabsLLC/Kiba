import React, {useEffect, useState} from 'react';
import {Box, Inline, Divider, Spinner} from '@stripe/ui-extension-sdk/ui';
import {createHttpClient, STRIPE_API_KEY} from '@stripe/ui-extension-sdk/http_client';
import type {ExtensionContextValue} from '@stripe/ui-extension-sdk/context';
import Stripe from 'stripe';

const stripe = new Stripe(STRIPE_API_KEY, {
  httpClient: createHttpClient() as unknown as Stripe.HttpClient,
});

type Briefing = {
  balance: string;
  paymentCount: number;
  paymentTotal: string;
  newCustomerCount: number;
};

// Plain, unhurried sentences instead of a dashboard of numbers.
function lines(b: Briefing): string[] {
  const out: string[] = [];

  if (b.paymentCount === 0) {
    out.push('Quiet day yesterday. No payments came in.');
  } else if (b.paymentCount === 1) {
    out.push(`One payment came in yesterday, worth ${b.paymentTotal}.`);
  } else {
    out.push(`${b.paymentCount} payments came in yesterday, worth ${b.paymentTotal} altogether.`);
  }

  if (b.newCustomerCount > 0) {
    out.push(
      b.newCustomerCount === 1
        ? 'One new person found you.'
        : `${b.newCustomerCount} new people found you.`
    );
  }

  out.push(`You have ${b.balance} ready to use right now.`);

  return out;
}

function formatMoney(amount: number, currency: string): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.toUpperCase(),
  }).format(amount / 100);
}

const KibaInsights = ({}: ExtensionContextValue) => {
  const [briefing, setBriefing] = useState<Briefing | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const dayAgo = Math.floor(Date.now() / 1000) - 24 * 60 * 60;

        const [charges, customers, balance] = await Promise.all([
          stripe.charges.list({created: {gte: dayAgo}, limit: 100}),
          stripe.customers.list({created: {gte: dayAgo}, limit: 100}),
          stripe.balance.retrieve(),
        ]);

        const successful = charges.data.filter((c) => c.paid && !c.refunded);
        const currency = balance.available[0]?.currency ?? 'usd';
        const total = successful.reduce((sum, c) => sum + c.amount, 0);
        const availableTotal = balance.available.reduce((sum, b) => sum + b.amount, 0);

        setBriefing({
          balance: formatMoney(availableTotal, currency),
          paymentCount: successful.length,
          paymentTotal: formatMoney(total, currency),
          newCustomerCount: customers.data.length,
        });
      } catch (e) {
        setError(true);
      }
    };

    load();
  }, []);

  return (
    <Box
      css={{
        padding: 'xlarge',
        stack: 'y',
        gap: 'large',
        backgroundColor: 'container',
      }}
    >
      <Inline css={{font: 'heading', color: 'primary'}}>Kiba Insights</Inline>

      {error && (
        <Inline css={{font: 'body', color: 'secondary'}}>
          Couldn't gather this morning's briefing. Try again shortly.
        </Inline>
      )}

      {!error && !briefing && (
        <Box css={{stack: 'x', gap: 'small', alignY: 'center'}}>
          <Spinner size="small" />
          <Inline css={{font: 'body', color: 'secondary'}}>Gathering this morning's briefing…</Inline>
        </Box>
      )}

      {briefing && (
        <Box css={{stack: 'y', gap: 'medium'}}>
          {lines(briefing).map((line, i) => (
            <Box key={i} css={{stack: 'y', gap: 'medium'}}>
              <Inline css={{font: 'body', color: 'primary'}}>{line}</Inline>
              {i < lines(briefing).length - 1 && <Divider />}
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
};

export default KibaInsights;
